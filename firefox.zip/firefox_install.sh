#!/bin/bash

mv ~/.mozilla/firefox ~&& mkdir ~/.mozilla/firefox && mv OS19ubuntu19.04.default  profiles.ini ~/.mozilla/firefox && rm  -Rfv  ~/.cache/mozilla && firefox/.cache/mozilla && killall firefox && firefox